﻿using System;
using System.Windows.Forms;
using System.Drawing; 

//multilingual
using System.Resources;
using System.Globalization;
using RRDM4ATMs;
using RRDM4ATMsWin;

namespace RRDMCashLess
{
    public partial class Form40 : Form
    {
        //multilingual
        CultureInfo culture;

        bool WActiveDirectory;
 
        string WOperator;
    
        string WSecLevel;
   
        string WSignedId;
        int WSignRecordNo;

        bool IsITMX;
        bool IsBank;
        bool IsCentralBank;

        string DecryptedPassword;

        string MSG; 

        //FormMainScreen NFormMainScreen;

        Form1ATMs NForm1ATMs;

        FormMainScreenCIT NFormMainScreenCIT;

        FormMainScreenSwitch NFormMainScreenSwitch;
        Form1ITMXCBT NForm1ITMXCBT;
        Form1ITMXBANKS NForm1ITMXBANKS;

        Form41 NForm41; 

        RRDMBanks Ba = new RRDMBanks(); 

        RRDMUsersAndSignedRecord Us = new RRDMUsersAndSignedRecord(); // Make class availble 

        RRDMGasParameters Gp = new RRDMGasParameters();

        RRDMActiveDirectory Ad = new RRDMActiveDirectory();

        RRDMImages Ri = new RRDMImages(); 

        ResourceManager LocRM = new ResourceManager("RRDMCashLess.appRes", typeof(Form40).Assembly);
 
        public Form40()
        {

            InitializeComponent();

            //TEST
         
            txtBoxPassword.PasswordChar = '*';

            // pictureBox1.Image = Ri.GetRRDMLogo();

            pictureBox1.BackgroundImage = appResImg.logo2;

            string DName = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;

            string PC_NotNet_DomainName = System.Environment.UserDomainName; 

            //
            // Check if Active Directory is applied 
            //
            // =============================================

            //public bool DomainFound; // Through .Net command
            //public bool ValidDomain; // Searching in Banks
            //public bool AdRRDMYes; // It was defined in Parameters that Active Directory was needed 
            //public bool UserInGroup; // User was checked and belongs to active directory group. 

            //
            // Check for electronic authorisation need
            //
            string ParId = "264";
            string OccurId = "1";
            //TEST
            WOperator = "CRBAGRAA"; 
            Gp.ReadParametersSpecificId(WOperator, ParId, OccurId, "", "");

            if (Gp.OccuranceNm == "YES") // Active directory needed
            {
                Ad.CheckActiveDirectory();

                if (Ad.ErrorFound == true)
                {
                    MessageBox.Show(Ad.ErrorOutput);
                    return;
                }

                if (Ad.DomainFound & Ad.ValidDomain & Ad.AdRRDMYes & Ad.UserInGroup)
                {
                    WActiveDirectory = true;
                }

                if (WActiveDirectory == true)
                {
                    label1.Hide();
                    label2.Hide();
                    label3.Hide();

                    comboBox2.Hide();
                    txtBoxPassword.Hide();

                    panel1.Show();

                    buttonLogin.Text = "Proceed";
                    buttonChange.Hide();

                    WOperator = Ad.Operator;

                    WSignedId = Ad.UserId;

                    Us.ReadUsersRecord(Ad.UserId);
                    if (Us.RecordFound == true)
                    {
                        labelName.Text = Us.UserName;

                        // ===========================================
                        // Assign User fields 
                        //*********************************************

                        if (Ad.NameFromActive) Us.UserName = Ad.UserName;
                        if (Ad.MobileFromActive) Us.MobileNo = Ad.UserPhone;
                        if (Ad.EmailFromActive) Us.email = Ad.UserMail;

                        Us.UpdateUser(Ad.UserId); // Update User with details from active directory 
                    }
                    else
                    {
                        MessageBox.Show("Active Directory user not found in RRDM. Ask RRDM administrator to examine! ");
                        return;
                    }

                }
                else
                {
                    WActiveDirectory = false;

                    panel1.Hide();
                }
            }
            else
            {
                WActiveDirectory = false;
                panel1.Hide();
            }

            //TEST
            comboBox2.Items.Add("1005");
            comboBox2.Items.Add("1006");
            comboBox2.Items.Add("487116");

            comboBox2.Items.Add("ADMIN-ATMS");
            comboBox2.Items.Add("1007_BDO"); 
            
            comboBox2.Items.Add("VISAUSER1");

            comboBox2.Items.Add("NOSTROUser");
            comboBox2.Items.Add("NOSTROAuther");
          
            comboBox2.Items.Add("1032-Level2");
            comboBox2.Items.Add("1033-Level3");
            comboBox2.Items.Add("1034-Level4");
            comboBox2.Items.Add("1035-Level5");
            comboBox2.Items.Add("Admin-Level10");
            comboBox2.Items.Add("Admin-Level11");

            comboBox2.Items.Add("ITMXUser1");
            comboBox2.Items.Add("ITMXUser2");
            comboBox2.Items.Add("BBLUser1");
            comboBox2.Items.Add("BBLUser2");
            comboBox2.Items.Add("CBTUser1");
            comboBox2.Items.Add("CBTUser2");

            comboBox2.Items.Add("500");
            comboBox2.Items.Add("03ServeUk");
            comboBox2.Items.Add("06ServeUk");
            comboBox2.Items.Add("BankMasterServeUk");

            comboBox2.Items.Add("999"); // Gas Master 

            SetValues();
        }

        private void SetValues() 
        {
            radioButtonATMs.Checked = false;
            radioButtonCARDS.Checked = false;
            radioButtonNOSTRO.Checked = false;
            radioButtonSWITCH.Checked = false;
            if (comboBox2.Text == "1005" || comboBox2.Text == "1006" || comboBox2.Text == "487116"
                || comboBox2.Text == "1032-Level2" || comboBox2.Text == "1033-Level3"
                || comboBox2.Text == "1034-Level4" || comboBox2.Text == "1035-Level5"
                || comboBox2.Text == "Admin-Level10" || comboBox2.Text == "Admin-Level11"
                || comboBox2.Text == "ADMIN-ATMS" || comboBox2.Text == "1007_BDO")
            radioButtonATMs.Checked = true;
            if (comboBox2.Text == "VISAUSER1")
                radioButtonCARDS.Checked = true;
            if (comboBox2.Text == "NOSTROUser" || comboBox2.Text == "NOSTROAuther")
                radioButtonNOSTRO.Checked = true;
            if (comboBox2.Text == "ITMXUser1" || comboBox2.Text == "ITMXUser2")
                radioButtonSWITCH.Checked = true;

            if (comboBox2.Text == "1005" || comboBox2.Text == "1006" || comboBox2.Text == "487116" 
                || comboBox2.Text == "ADMIN-ATMS" || comboBox2.Text == "1007_BDO"
                || comboBox2.Text == "Admin-Level10" || comboBox2.Text == "Admin-Level11"
                               || comboBox2.Text == "NOSTROUser" || comboBox2.Text == "NOSTROAuther" || comboBox2.Text == "VISAUSER1")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "999")
            {
                //txtBoxPassword.Text = "hLGxlR51";
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "ITMXUser1")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "BBLUser1")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "BBLUser2")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "CBTUser1")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "CBTUser2")
            {
                txtBoxPassword.Text = "12345678";
            }

            if (comboBox2.Text == "1032-Level2")
            {
                txtBoxPassword.Text = "12345678";
            }
            if (comboBox2.Text == "1033-Level3")
            {
                txtBoxPassword.Text = "12345678";
            }
            if (comboBox2.Text == "1034-Level4")
            {
                txtBoxPassword.Text = "12345678";
            }
            if (comboBox2.Text == "1035-Level5")
            {
                txtBoxPassword.Text = "12345678";
            }

            comboBox1.Text = "English";

            //multilingual
            culture = CultureInfo.CurrentCulture;
            //culture = CultureInfo.CreateSpecificCulture("fr-FR");
            SetCulture();
        }


        private void SetCulture()
        {
            // Assign the string for the "strMessage" key to a message box.
            labelStep1.Text = LocRM.GetString("Login", culture);
            buttonLogin.Text = LocRM.GetString("Login", culture);
            label3.Text = LocRM.GetString("LoginInstruction", culture);
            label1.Text = LocRM.GetString("UserIdCapital", culture);
            label2.Text = LocRM.GetString("PasswordCapital", culture);

            if (WActiveDirectory) buttonLogin.Text = "Proceed";

            this.Text = LocRM.GetString("Login", culture);
        }
        // LOGIN

        private void buttonLogin_Click(object sender, EventArgs e)
        {
           
            //if (comboBox2.Text == "ADMIN")
            //{
            //    Form82 NForm82;
            //    NForm82 = new Form82(WSignedId, WSignRecordNo, WSecLevel, WOperator);
            //    NForm82.ShowDialog();
            //    return; 
            //}

            if (WActiveDirectory == false)
            {
                // Check data not to be empty 

                if (comboBox2.Text == "")
                {
                    MessageBox.Show("Please enter your user Id");
                    return;
                }

                if (txtBoxPassword.Text == "")
                {
                    MessageBox.Show("Please enter your password");
                    return;
                }

                WSignedId = comboBox2.Text;

                // =============================================
                Us.ReadUsersRecord(WSignedId); // Read USER record for the signed user

                if (Us.ErrorFound == true)
                {
                    MessageBox.Show("System Problem. Most likely SQL Not loaded yet"+ Environment.NewLine
                                       + "Wait for few seconds and retry to login"
                                        );
                    return;
                }

                // ===========================================
                if (Us.RecordFound == false)
                {
                    MSG = LocRM.GetString("Form40MSG002", culture);
                    MessageBox.Show(comboBox2.Text, MSG);
                    //   MessageBox.Show(" User Not Found ");
                    return;
                }
                else
                {
                    DecryptedPassword = Us.DecryptPassword(Us.PassWord);
                   
                    if (txtBoxPassword.Text != DecryptedPassword)
                    {
                        MSG = LocRM.GetString("Form40MSG003", culture);
                        MessageBox.Show("For User: " + comboBox2.Text, MSG);
                        // MessageBox.Show(" Wrong User or Password ");
                        return;
                    }
                } 
               

                Gp.ReadParametersSpecificId(Us.Operator, "451", "2", "", "");
                int Temp = ((int)Gp.Amount);

                if (DateTime.Now > Us.DtToBeChanged)
                {
                    // Your Password has expired
                    MessageBox.Show("Your Password has expired");
                    return;
                }

                if (DateTime.Now > Us.DtToBeChanged.AddDays(-Temp))
                {
                    // Your Password will expire in so many days
                    int TempRem = Convert.ToInt32((Us.DtToBeChanged - DateTime.Now).TotalDays);
                    MessageBox.Show("Days reamaining to change your password : " + TempRem.ToString());
                }

                if (Us.ForceChangePassword == true)
                {
                    // Your Password must change 
                    MessageBox.Show("Please Change password");
                    return;
                }

                Us.DtChanged = DateTime.Now;
                Us.DtToBeChanged = DateTime.Now.AddDays(Temp);
                Us.ForceChangePassword = true;

                WOperator = Us.Operator;
                WSecLevel = Us.SecLevel;

                if (WSecLevel == "07" & Us.PassWord == "123")
                {
                    MessageBox.Show("Change your password please");
                    return;
                }

                if (Us.PassWord == "99RESET9") // Password was reset  
                {
                    MessageBox.Show("Change your password please");
                    return;
                }
            }      

            Ba.ReadBank(WOperator);

            /*
            if (DateTime.Today > Ba.LastMatchingDtTm.Date)
            {
                // Call the method in class for matching 
                HostMatchingClassGeneralLedger Hm = new HostMatchingClassGeneralLedger();
                bool HostMatched = false; // find the unmatched 
                Hm.MakeMatching(WBankId, HostMatched);
                Ba.ReadBank(WBankId); 
                Ba.LastMatchingDtTm = DateTime.Now; // Assign new value 
                Ba.UpdateBank(WBankId); 
            }
             */

            Us.ReadSignedActivity(WSignedId); // Read to check if user is already signed in 
            if (Us.RecordFound == true & Us.SignInStatus == true)
            {
                if (MessageBox.Show("Our records show that you are already loged in the system. Do you want to force new login?", "Message",
                                     MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                                     == DialogResult.Yes)
                {
                    // Leave process to continue 
                }
                else
                {
                    return;
                }
            }

            Us.UserId = WSignedId;

            Us.SecLevel = WSecLevel; 

            Us.Culture = comboBox1.Text;

            Us.SignInStatus = true;

            Us.DtTmIn = DateTime.Now;
            Us.DtTmOut = DateTime.Now;

            // INITIALISE 
            Us.ATMS_Reconciliation = false;
            Us.CARDS_Settlement = false;
            Us.NOSTRO_Reconciliation = false;
            Us.SWITCH_Reconciliation = false;

            // SET
            if (radioButtonATMs.Checked == true)
                Us.ATMS_Reconciliation = true;
            if (radioButtonCARDS.Checked == true)
                Us.CARDS_Settlement = true;
            if (radioButtonNOSTRO.Checked == true)
                Us.NOSTRO_Reconciliation = true;
            if (radioButtonSWITCH.Checked == true)
                Us.SWITCH_Reconciliation = true;

            Us.Replenishment = false;
            Us.Reconciliation = false;
            Us.OtherActivity = true;

            WSignRecordNo = Us.InsertSignedActivity(WSignedId);

            if (WSignedId == "500")
            {
                // READ DETAILS OF ACCESS RIGHTS AND GO TO FORM1 
                NFormMainScreenCIT = new FormMainScreenCIT(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                //NFormMainScreenCIT.LoggingOut
                NFormMainScreenCIT.LoggingOut += NFormMainScreenCIT_LoggingOut;
                NFormMainScreenCIT.Show();
                this.Hide();
                return; 
            }
            if (WOperator == "ITMX")
            {          

                if (Us.BankId == "ITMX")
                {
                    IsITMX = true; 
                }
                else
                {
                    if (Us.BankId == "CBT")
                    {
                        IsCentralBank = true; 
                    }
                    else
                    {
                        IsBank = true; 
                    }
                }

                if (IsITMX)
                {
                    //This is ITMX and other Banks 
                    // READ DETAILS OF ACCESS RIGHTS AND GO TO FORM1 
                    NFormMainScreenSwitch = new FormMainScreenSwitch(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                    //NFormMainScreenCIT.LoggingOut
                    NFormMainScreenSwitch.LoggingOut += NFormMainScreenSwitch_LoggingOut;
                    NFormMainScreenSwitch.Show();
                    this.Hide();
                }

                if (IsBank)
                {
                    // THIS IS ANY MEMBER BANK in THAILAND 
                    // READ DETAILS OF ACCESS RIGHTS AND GO TO FORM1 
                    NForm1ITMXBANKS = new Form1ITMXBANKS(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                    //NFormMainScreenCIT.LoggingOut
                    NForm1ITMXBANKS.LoggingOut += NForm1ITMXBANKS_LoggingOut;
                    NForm1ITMXBANKS.Show();
                    this.Hide();
                }


                if (IsCentralBank)
                {
                    // THIS IS CENTRAL BANK THAILAND 
                    // READ DETAILS OF ACCESS RIGHTS AND GO TO FORM1 
                    NForm1ITMXCBT = new Form1ITMXCBT(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                    //NFormMainScreenCIT.LoggingOut
                    NForm1ITMXCBT.LoggingOut += NForm1ITMXCBT_LoggingOut;
                    NForm1ITMXCBT.Show();
                    this.Hide();
                }           
            }
            else
            {
                if (Us.SecLevel == "10" || Us.SecLevel == "11")
                {
                    Form_ATMS_ADMIN NForm_ATMS_ADMIN;

                    NForm_ATMS_ADMIN = new Form_ATMS_ADMIN(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                    NForm_ATMS_ADMIN.LoggingOut += NForm_ATMS_ADMIN_LoggingOut;
                    NForm_ATMS_ADMIN.Show();
                    //return; 
                    this.Hide();
                }
            
                if (WSecLevel == "02"
                    || WSecLevel == "03"
                    || WSecLevel == "04"
                    || WSecLevel == "05"
                    || WSecLevel == "06"
                    || WSecLevel == "07"
                    || WSecLevel == "08"
                    || WSecLevel == "09"
                    )
                {
                    if (radioButtonATMs.Checked == true)
                    {
                        NForm1ATMs = new Form1ATMs(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                        NForm1ATMs.LoggingOut += NForm1ATMs_LoggingOut;
                        NForm1ATMs.Show();
                        this.Hide();
                    }
                    if (radioButtonCARDS.Checked == true || radioButtonNOSTRO.Checked == true)
                    {
                        Form_NOSTRO_OPERATIONAL NForm_NOSTRO_OPERATIONAL;

                        NForm_NOSTRO_OPERATIONAL = new Form_NOSTRO_OPERATIONAL(WSignedId, WSignRecordNo, WSecLevel, WOperator);
                        NForm_NOSTRO_OPERATIONAL.LoggingOut += NForm_NOSTRO_OPERATIONAL_LoggingOut;
                        NForm_NOSTRO_OPERATIONAL.Show();
                        this.Hide();
                    }
                }

            }      
        }

        void NForm_ATMS_ADMIN_LoggingOut(object sender, EventArgs e)
        {

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }
        void NForm_ATMS_OPERATIONAL_LoggingOut(object sender, EventArgs e)
        {

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }
        void NForm_NOSTRO_OPERATIONAL_LoggingOut(object sender, EventArgs e)
        {

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }
        void NForm1ATMs_LoggingOut(object sender, EventArgs e)
        {
           
            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false; 

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

         //   SetValues();
            this.Dispose();
        }

        void NFormMainScreenCIT_LoggingOut(object sender, EventArgs e)
        {
          

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }

        void NForm1ITMXBANKS_LoggingOut(object sender, EventArgs e)
        {
           

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }

        void NFormMainScreenSwitch_LoggingOut(object sender, EventArgs e)
        {
            NFormMainScreenSwitch.Dispose();

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }

        void NForm1ITMXCBT_LoggingOut(object sender, EventArgs e)
        {
            //NForm1ITMXCBT.Dispose();

            Us.ReadSignedActivityByKey(WSignRecordNo);

            Us.SignInStatus = false;

            Us.DtTmOut = DateTime.Now;

            Us.UpdateSignedInTableDateTmOut(WSignRecordNo);

            //   SetValues();
            this.Dispose();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString().Equals("English"))
            {
                culture = CultureInfo.CreateSpecificCulture("el-GR");
            }
            if (comboBox1.SelectedItem.ToString().Equals("Français"))
            {
                culture = CultureInfo.CreateSpecificCulture("fr-FR");
            }

            SetCulture();
        }
        // Change password 

        private void buttonChange_Click_1(object sender, EventArgs e)
        {
            // Check data not to be empty 

            if (comboBox2.Text == "")
            {
                MessageBox.Show("Please enter your user Id");
                return;
            }

            if (txtBoxPassword.Text == "")
            {
                MessageBox.Show("Please enter your password");
                return;
            }

            WSignedId = comboBox2.Text;

            // =============================================
            Us.ReadUsersRecord(WSignedId); // Read USER record for the signed user

            WOperator = Us.Operator;

            // ===========================================
            if (Us.RecordFound == false)
            {
                MSG = LocRM.GetString("Form40MSG002", culture);
                MessageBox.Show(comboBox2.Text, MSG);
                //   MessageBox.Show(" User Not Found ");
                return;
            }
            else
            {
                DecryptedPassword = Us.DecryptPassword(Us.PassWord);

                if (txtBoxPassword.Text != DecryptedPassword)
                {
                    MSG = LocRM.GetString("Form40MSG003", culture);
                    MessageBox.Show("For User: " + comboBox2.Text, MSG);
                    // MessageBox.Show(" Wrong User or Password ");
                    return;
                }
            } 
            // Inititilize password 
            txtBoxPassword.Text = "";
            NForm41 = new Form41(WSignedId, WOperator);
            NForm41.Show();
        }
// If change 
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false; 
            SetValues();
        }
//Show Characters 
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                if (txtBoxPassword.Text == "")
                {
                    MessageBox.Show("Please enter your password");
                    return;
                }

                WSignedId = comboBox2.Text;

                // =============================================
                Us.ReadUsersRecord(WSignedId); // Read USER record for the signed user

                if (Us.ErrorFound == true)
                {
                    MessageBox.Show("System Problem. Most likely SQL Not loaded yet" + Environment.NewLine
                                       + "Wait for few seconds and retry to login"
                                        );
                    return;
                }

                // ===========================================
                if (Us.RecordFound == false)
                {
                    MSG = LocRM.GetString("Form40MSG002", culture);
                    MessageBox.Show(comboBox2.Text, MSG);
                    //   MessageBox.Show(" User Not Found ");
                    return;
                }
                else
                {
                    DecryptedPassword = Us.DecryptPassword(Us.PassWord);

                    if (txtBoxPassword.Text == DecryptedPassword)
                    {
                       
                        MessageBox.Show("You have entered the correct password. Characters cannot be shown. ");
                        checkBox1.Checked = false; 
                        return;
                    }
                }

                //Enable to see characters of entered password
                txtBoxPassword.PasswordChar = checkBox1.Checked ? '\0' : '*';

            }
            else
            {
                // go back to hide characters of entered password 
                txtBoxPassword.PasswordChar = '*';
            }
        }
// On password change 
        private void txtBoxPassword_TextChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false; 
        }
    }
}

